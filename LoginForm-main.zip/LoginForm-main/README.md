# LoginForm
Animated Login Form
<h3>Tools</h3>
<ul>
  <li>HTML</li>
  <li>CSS</li>
  <li>JS</li>
  <li>JQuery</li>
</ul>


https://user-images.githubusercontent.com/89544871/133996647-1f09a944-539b-4a06-bd43-51ddae858a13.mp4

